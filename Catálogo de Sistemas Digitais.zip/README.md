
  # Catálogo de Sistemas Digitais

  This is a code bundle for Catálogo de Sistemas Digitais. The original project is available at https://www.figma.com/design/B9JII1wBe6bRk2UOdoof5J/Cat%C3%A1logo-de-Sistemas-Digitais.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  